-- ============================================================
-- AssetFlow Resources Module
-- File: 05_resources.sql
-- MySQL 8.0.45 / InnoDB
-- ============================================================

-- ============================================================
-- Table: resources
-- Stores bookable organizational resources such as meeting rooms,
-- conference halls, parking spaces, vehicles, and equipment.
-- A resource may optionally reference one tracked asset.
-- ============================================================

CREATE TABLE resources (
    resource_id INT AUTO_INCREMENT PRIMARY KEY,
    resource_type ENUM(
        'meeting_room',
        'conference_hall',
        'parking_space',
        'vehicle',
        'equipment',
        'other'
    ) NOT NULL,
    resource_code VARCHAR(50) NOT NULL,
    resource_name VARCHAR(150) NOT NULL,
    asset_id INT NULL,
    location_id INT NULL,
    capacity INT NULL,
    description TEXT NULL,
    status ENUM('active', 'inactive', 'unavailable') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    -- Enforces zero-or-one Resource record for each linked Asset.
    CONSTRAINT uq_resources_asset_id UNIQUE (asset_id),
    CONSTRAINT uq_resources_resource_code UNIQUE (resource_code),

    INDEX idx_resources_location_id (location_id),
    INDEX idx_resources_status (status),
    INDEX idx_resources_resource_type (resource_type),

    CONSTRAINT fk_resources_asset
        FOREIGN KEY (asset_id)
        REFERENCES assets (asset_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,

    CONSTRAINT fk_resources_location
        FOREIGN KEY (location_id)
        REFERENCES locations (location_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Table: resource_bookings
-- Stores time-based bookings for resources. Booking overlap
-- validation and approval workflow rules are enforced by
-- application/service logic.
-- ============================================================

CREATE TABLE resource_bookings (
    resource_booking_id INT AUTO_INCREMENT PRIMARY KEY,
    resource_id INT NOT NULL,
    requested_by_employee_id INT NOT NULL,
    booking_department_id INT NULL,
    booking_start_at DATETIME NOT NULL,
    booking_end_at DATETIME NOT NULL,
    checked_in_at DATETIME NULL,
    checked_out_at DATETIME NULL,
    booking_purpose TEXT NOT NULL,
    booking_status ENUM(
        'pending',
        'approved',
        'rejected',
        'upcoming',
        'ongoing',
        'completed',
        'cancelled'
    ) NOT NULL DEFAULT 'pending',
    approved_by_employee_id INT NULL,
    approval_decision_at DATETIME NULL,
    approval_rejection_reason TEXT NULL,
    cancelled_by_employee_id INT NULL,
    cancelled_at DATETIME NULL,
    cancellation_reason TEXT NULL,
    rescheduled_from_booking_id INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_resource_bookings_resource_id (resource_id),
    INDEX idx_resource_bookings_requested_by_employee_id (
        requested_by_employee_id
    ),
    INDEX idx_resource_bookings_booking_department_id (
        booking_department_id
    ),
    INDEX idx_resource_bookings_approved_by_employee_id (
        approved_by_employee_id
    ),
    INDEX idx_resource_bookings_cancelled_by_employee_id (
        cancelled_by_employee_id
    ),
    INDEX idx_resource_bookings_rescheduled_from_booking_id (
        rescheduled_from_booking_id
    ),
    INDEX idx_resource_bookings_status (booking_status),
    INDEX idx_resource_bookings_booking_start_at (booking_start_at),
    INDEX idx_resource_bookings_booking_end_at (booking_end_at),
    INDEX idx_resource_bookings_resource_dates (
        resource_id,
        booking_start_at,
        booking_end_at
    ),
    INDEX idx_resource_bookings_status_start_at (
        booking_status,
        booking_start_at
    ),

    CONSTRAINT fk_resource_bookings_resource
        FOREIGN KEY (resource_id)
        REFERENCES resources (resource_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_resource_bookings_requested_by_employee
        FOREIGN KEY (requested_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_resource_bookings_booking_department
        FOREIGN KEY (booking_department_id)
        REFERENCES departments (department_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_resource_bookings_approved_by_employee
        FOREIGN KEY (approved_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,

    CONSTRAINT fk_resource_bookings_cancelled_by_employee
        FOREIGN KEY (cancelled_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,

    CONSTRAINT fk_resource_bookings_rescheduled_from_booking
        FOREIGN KEY (rescheduled_from_booking_id)
        REFERENCES resource_bookings (resource_booking_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;