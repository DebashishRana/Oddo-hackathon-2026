-- ============================================================
-- AssetFlow System Module
-- File: 08_system.sql
-- MySQL 8.0.45 / InnoDB
-- ============================================================

-- ============================================================
-- Table: notifications
-- Stores system-generated and user-facing notifications for
-- employees, including delivery and read-status information.
-- Related entity references are polymorphic and are resolved by
-- application/service logic.
-- ============================================================

CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    notification_type ENUM(
        'system',
        'asset',
        'maintenance',
        'booking',
        'transfer',
        'audit',
        'security',
        'other'
    ) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    related_entity_type VARCHAR(50) NULL,
    related_entity_id INT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    read_at DATETIME NULL,
    delivery_status ENUM(
        'pending',
        'delivered',
        'failed'
    ) NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_notifications_employee_id (employee_id),
    INDEX idx_notifications_notification_type (notification_type),
    INDEX idx_notifications_delivery_status (delivery_status),
    INDEX idx_notifications_is_read (is_read),
    INDEX idx_notifications_created_at (created_at),
    INDEX idx_notifications_employee_read_created_at (
        employee_id,
        is_read,
        created_at
    ),
    INDEX idx_notifications_related_entity (
        related_entity_type,
        related_entity_id
    ),

    CONSTRAINT fk_notifications_employee
        FOREIGN KEY (employee_id)
        REFERENCES employees (employee_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Table: activity_logs
-- Stores an immutable audit trail of employee and system actions.
-- Entity references are polymorphic and are resolved by
-- application/service logic.
-- ============================================================

CREATE TABLE activity_logs (
    activity_log_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NULL,
    activity_type VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INT NULL,
    description TEXT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(500) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_activity_logs_employee_id (employee_id),
    INDEX idx_activity_logs_activity_type (activity_type),
    INDEX idx_activity_logs_entity_type (entity_type),
    INDEX idx_activity_logs_entity_id (entity_id),
    INDEX idx_activity_logs_created_at (created_at),
    INDEX idx_activity_logs_entity_reference (
        entity_type,
        entity_id
    ),
    INDEX idx_activity_logs_employee_created_at (
        employee_id,
        created_at
    ),

    CONSTRAINT fk_activity_logs_employee
        FOREIGN KEY (employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;