CREATE DATABASE IF NOT EXISTS assetflow_dev;
USE assetflow_dev;