-- ============================================================
-- AssetFlow Maintenance Module
-- File: 06_maintenance.sql
-- MySQL 8.0.45 / InnoDB
-- ============================================================

-- ============================================================
-- Table: maintenance_requests
-- Stores preventive and corrective maintenance requests for
-- tracked assets, including approval, assignment, scheduling,
-- completion, and maintenance-cost details.
-- ============================================================

CREATE TABLE maintenance_requests (
    maintenance_request_id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    maintenance_type ENUM(
        'preventive',
        'corrective',
        'repair',
        'inspection',
        'other'
    ) NOT NULL,
    priority ENUM(
        'low',
        'medium',
        'high',
        'critical'
    ) NOT NULL DEFAULT 'medium',
    request_status ENUM(
        'pending',
        'approved',
        'rejected',
        'assigned',
        'scheduled',
        'in_progress',
        'completed',
        'cancelled'
    ) NOT NULL DEFAULT 'pending',
    requested_by_employee_id INT NOT NULL,
    assigned_technician_employee_id INT NULL,
    approved_by_employee_id INT NULL,
    description TEXT NOT NULL,
    attachment_storage_path VARCHAR(500) NULL,
    scheduled_date DATETIME NULL,
    completed_date DATETIME NULL,
    estimated_cost DECIMAL(15, 2) NULL,
    actual_cost DECIMAL(15, 2) NULL,
    vendor_name VARCHAR(150) NULL,
    approval_decision_at DATETIME NULL,
    approval_notes TEXT NULL,
    completion_notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_maintenance_requests_asset_id (asset_id),
    INDEX idx_maintenance_requests_requested_by_employee_id (
        requested_by_employee_id
    ),
    INDEX idx_maintenance_requests_assigned_technician_employee_id (
        assigned_technician_employee_id
    ),
    INDEX idx_maintenance_requests_approved_by_employee_id (
        approved_by_employee_id
    ),
    INDEX idx_maintenance_requests_status (request_status),
    INDEX idx_maintenance_requests_priority (priority),
    INDEX idx_maintenance_requests_scheduled_date (scheduled_date),
    INDEX idx_maintenance_requests_completed_date (completed_date),
    INDEX idx_maintenance_requests_asset_status (
        asset_id,
        request_status
    ),

    CONSTRAINT fk_maintenance_requests_asset
        FOREIGN KEY (asset_id)
        REFERENCES assets (asset_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_maintenance_requests_requested_by_employee
        FOREIGN KEY (requested_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_maintenance_requests_assigned_technician_employee
        FOREIGN KEY (assigned_technician_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,

    CONSTRAINT fk_maintenance_requests_approved_by_employee
        FOREIGN KEY (approved_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;