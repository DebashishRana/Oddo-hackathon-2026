-- ============================================================
-- AssetFlow Organization Module
-- MySQL 8.0.45 / InnoDB
-- ============================================================

-- ============================================================
-- Table: departments
-- Created first because employees references departments.
-- Employee-related foreign keys are added after employees exists.
-- ============================================================

CREATE TABLE departments (
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    department_code VARCHAR(50) NOT NULL,
    department_name VARCHAR(150) NOT NULL,
    description TEXT NULL,
    department_email VARCHAR(255) NULL,
    department_phone VARCHAR(30) NULL,
    parent_department_id INT NULL,
    head_employee_id INT NULL,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_by_employee_id INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT uq_departments_department_code UNIQUE (department_code),

    CONSTRAINT fk_departments_parent_department
        FOREIGN KEY (parent_department_id)
        REFERENCES departments (department_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Table: employees
-- Stores organizational and employment information only.
-- Authentication credentials are held separately in users.
-- ============================================================

CREATE TABLE employees (
    employee_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_code VARCHAR(50) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    designation VARCHAR(150) NOT NULL,
    work_email VARCHAR(255) NOT NULL,
    phone_number VARCHAR(30) NULL,
    department_id INT NOT NULL,
    employment_status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    joined_date DATE NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT uq_employees_employee_code UNIQUE (employee_code),
    CONSTRAINT uq_employees_work_email UNIQUE (work_email),

    INDEX idx_employees_department_id (department_id),

    CONSTRAINT fk_employees_department
        FOREIGN KEY (department_id)
        REFERENCES departments (department_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Table: users
-- Stores authentication and account-security information only.
-- Enforces one employee to zero-or-one user account.
-- ============================================================

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    account_status ENUM('pending_activation', 'active', 'locked', 'disabled')
        NOT NULL DEFAULT 'pending_activation',
    email_verified_at DATETIME NULL,
    last_login_at DATETIME NULL,
    last_password_changed_at DATETIME NULL,
    failed_login_count INT NOT NULL DEFAULT 0,
    locked_until DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT uq_users_employee_id UNIQUE (employee_id),

    CONSTRAINT fk_users_employee
        FOREIGN KEY (employee_id)
        REFERENCES employees (employee_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Table: roles
-- Defines application roles such as Admin, Asset Manager,
-- Department Head, and Employee.
-- ============================================================

CREATE TABLE roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_code VARCHAR(50) NOT NULL,
    role_name VARCHAR(100) NOT NULL,
    description TEXT NULL,
    is_system_role BOOLEAN NOT NULL DEFAULT TRUE,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',

    CONSTRAINT uq_roles_role_code UNIQUE (role_code),
    CONSTRAINT uq_roles_role_name UNIQUE (role_name)
) ENGINE=InnoDB;

-- ============================================================
-- Table: employee_roles
-- Bridge table for the many-to-many Employee-to-Role relationship.
-- ============================================================

CREATE TABLE employee_roles (
    employee_role_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    role_id INT NOT NULL,
    assigned_by_employee_id INT NULL,
    assignment_reason VARCHAR(255) NULL,
    assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    revoked_at DATETIME NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,

    -- One assignment record per employee-role pair.
    CONSTRAINT uq_employee_roles_employee_role UNIQUE (employee_id, role_id),

    CONSTRAINT fk_employee_roles_employee
        FOREIGN KEY (employee_id)
        REFERENCES employees (employee_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_employee_roles_role
        FOREIGN KEY (role_id)
        REFERENCES roles (role_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_employee_roles_assigned_by
        FOREIGN KEY (assigned_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Department-to-Employee foreign keys
-- Added after employees is created to avoid circular creation issues.
-- ============================================================

ALTER TABLE departments
    ADD CONSTRAINT fk_departments_head_employee
        FOREIGN KEY (head_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,

    ADD CONSTRAINT fk_departments_created_by_employee
        FOREIGN KEY (created_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE;

-- Business rule enforced by application/service logic:
-- a selected department head must hold the Department Head role.