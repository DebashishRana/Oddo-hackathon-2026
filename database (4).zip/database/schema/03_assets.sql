-- ============================================================
-- AssetFlow Assets Module
-- File: 03_assets.sql
-- MySQL 8.0.45 / InnoDB
-- ============================================================

-- ============================================================
-- Table: asset_categories
-- Stores master classifications such as Electronics, Furniture,
-- Vehicles, Equipment, and Shared Resources.
-- ============================================================

CREATE TABLE asset_categories (
    asset_category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_code VARCHAR(50) NOT NULL,
    category_name VARCHAR(100) NOT NULL,
    description TEXT NULL,
    default_warranty_months INT NULL,
    default_maintenance_interval_days INT NULL,
    default_useful_life_months INT NULL,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT uq_asset_categories_category_code UNIQUE (category_code),
    CONSTRAINT uq_asset_categories_category_name UNIQUE (category_name)
) ENGINE=InnoDB;

-- ============================================================
-- Table: locations
-- Stores physical sites, buildings, floors, rooms, and areas.
-- Supports a parent-child location hierarchy.
-- ============================================================

CREATE TABLE locations (
    location_id INT AUTO_INCREMENT PRIMARY KEY,
    location_code VARCHAR(50) NOT NULL,
    location_name VARCHAR(150) NOT NULL,
    building_site VARCHAR(150) NULL,
    floor VARCHAR(50) NULL,
    room_area VARCHAR(100) NULL,
    address_description TEXT NULL,
    parent_location_id INT NULL,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT uq_locations_location_code UNIQUE (location_code),

    INDEX idx_locations_parent_location_id (parent_location_id),

    CONSTRAINT fk_locations_parent_location
        FOREIGN KEY (parent_location_id)
        REFERENCES locations (location_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Table: assets
-- Stores the current operational state of every tracked asset.
-- Historical lifecycle changes are retained in asset_status_history.
-- ============================================================

CREATE TABLE assets (
    asset_id INT AUTO_INCREMENT PRIMARY KEY,
    asset_tag VARCHAR(50) NOT NULL,
    qr_code VARCHAR(100) NULL,
    asset_name VARCHAR(150) NOT NULL,
    asset_category_id INT NOT NULL,
    serial_number VARCHAR(100) NULL,
    acquisition_date DATE NULL,
    acquisition_cost DECIMAL(15, 2) NULL,
    owning_department_id INT NULL,
    current_location_id INT NULL,
    current_status ENUM(
        'available',
        'allocated',
        'reserved',
        'under_maintenance',
        'lost',
        'retired',
        'disposed'
    ) NOT NULL DEFAULT 'available',
    current_condition ENUM(
        'new',
        'good',
        'fair',
        'damaged',
        'unusable'
    ) NOT NULL DEFAULT 'good',
    is_bookable BOOLEAN NOT NULL DEFAULT FALSE,
    manufacturer VARCHAR(100) NULL,
    model VARCHAR(100) NULL,
    supplier_name VARCHAR(150) NULL,
    purchase_invoice_number VARCHAR(100) NULL,
    warranty_expiry_date DATE NULL,
    retirement_target_date DATE NULL,
    notes TEXT NULL,
    registered_by_employee_id INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT uq_assets_asset_tag UNIQUE (asset_tag),
    CONSTRAINT uq_assets_qr_code UNIQUE (qr_code),
    CONSTRAINT uq_assets_serial_number UNIQUE (serial_number),

    INDEX idx_assets_asset_category_id (asset_category_id),
    INDEX idx_assets_owning_department_id (owning_department_id),
    INDEX idx_assets_current_location_id (current_location_id),
    INDEX idx_assets_registered_by_employee_id (registered_by_employee_id),
    INDEX idx_assets_current_status (current_status),
    INDEX idx_assets_bookable_status (is_bookable, current_status),

    CONSTRAINT fk_assets_asset_category
        FOREIGN KEY (asset_category_id)
        REFERENCES asset_categories (asset_category_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_assets_owning_department
        FOREIGN KEY (owning_department_id)
        REFERENCES departments (department_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,

    CONSTRAINT fk_assets_current_location
        FOREIGN KEY (current_location_id)
        REFERENCES locations (location_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,

    CONSTRAINT fk_assets_registered_by_employee
        FOREIGN KEY (registered_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Table: asset_documents
-- Stores metadata and storage references for asset photos,
-- warranty files, manuals, and other supporting documents.
-- File binaries are stored outside the database.
-- ============================================================

CREATE TABLE asset_documents (
    document_id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    filename VARCHAR(255) NOT NULL,
    file_type VARCHAR(100) NOT NULL,
    storage_path_url VARCHAR(500) NOT NULL,
    uploaded_by_employee_id INT NULL,
    uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_asset_documents_asset_id (asset_id),
    INDEX idx_asset_documents_uploaded_by_employee_id (uploaded_by_employee_id),

    CONSTRAINT fk_asset_documents_asset
        FOREIGN KEY (asset_id)
        REFERENCES assets (asset_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    CONSTRAINT fk_asset_documents_uploaded_by_employee
        FOREIGN KEY (uploaded_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Table: asset_status_history
-- Provides an immutable lifecycle audit trail for each asset.
-- The current operational state remains stored on assets.
-- ============================================================

CREATE TABLE asset_status_history (
    asset_status_history_id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    status ENUM(
        'available',
        'allocated',
        'reserved',
        'under_maintenance',
        'lost',
        'retired',
        'disposed'
    ) NOT NULL,
    changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    changed_by_employee_id INT NULL,
    source_process VARCHAR(50) NULL,
    source_record_id INT NULL,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_asset_status_history_asset_id (asset_id),
    INDEX idx_asset_status_history_changed_by_employee_id (changed_by_employee_id),
    INDEX idx_asset_status_history_asset_changed_at (asset_id, changed_at),
    INDEX idx_asset_status_history_status (status),

    CONSTRAINT fk_asset_status_history_asset
        FOREIGN KEY (asset_id)
        REFERENCES assets (asset_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_asset_status_history_changed_by_employee
        FOREIGN KEY (changed_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;