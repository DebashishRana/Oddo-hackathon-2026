-- ============================================================
-- AssetFlow Operations Module
-- File: 04_operations.sql
-- MySQL 8.0.45 / InnoDB
-- ============================================================

-- ============================================================
-- Table: asset_allocations
-- Stores complete asset custody history. Historical allocation
-- rows are retained and must not be overwritten or deleted.
-- Exactly one allocation recipient (employee or department) is
-- enforced by application/service logic.
-- ============================================================

-- Business rule:
-- Only one ACTIVE allocation may exist per asset.
-- This is enforced by application/service logic.

CREATE TABLE asset_allocations (
    asset_allocation_id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    allocated_to_employee_id INT NULL,
    allocated_to_department_id INT NULL,
    allocated_by_employee_id INT NULL,
    approved_by_employee_id INT NULL,
    allocation_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expected_return_date DATETIME NULL,
    actual_return_date DATETIME NULL,
    allocation_status ENUM(
        'pending',
        'active',
        'returned',
        'transferred',
        'cancelled'
    ) NOT NULL DEFAULT 'pending',
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_asset_allocations_asset_id (asset_id),
    INDEX idx_asset_allocations_allocated_to_employee_id (
        allocated_to_employee_id
    ),
    INDEX idx_asset_allocations_allocated_to_department_id (
        allocated_to_department_id
    ),
    INDEX idx_asset_allocations_allocated_by_employee_id (
        allocated_by_employee_id
    ),
    INDEX idx_asset_allocations_approved_by_employee_id (
        approved_by_employee_id
    ),
    INDEX idx_asset_allocations_status (allocation_status),
    INDEX idx_asset_allocations_allocation_date (allocation_date),
    INDEX idx_asset_allocations_expected_return_date (expected_return_date),
    INDEX idx_asset_allocations_actual_return_date (actual_return_date),
    INDEX idx_asset_allocations_asset_status (asset_id, allocation_status),

    CONSTRAINT fk_asset_allocations_asset
        FOREIGN KEY (asset_id)
        REFERENCES assets (asset_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_asset_allocations_allocated_to_employee
        FOREIGN KEY (allocated_to_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_asset_allocations_allocated_to_department
        FOREIGN KEY (allocated_to_department_id)
        REFERENCES departments (department_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_asset_allocations_allocated_by_employee
        FOREIGN KEY (allocated_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,

    CONSTRAINT fk_asset_allocations_approved_by_employee
        FOREIGN KEY (approved_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Table: transfer_requests
-- Stores transfer workflow requests against an existing asset
-- allocation. Current and requested ownership are retained as
-- snapshots for auditability and workflow validation.
-- Exactly one current owner and one requested owner are enforced
-- by application/service logic.
-- ============================================================

CREATE TABLE transfer_requests (
    transfer_request_id INT AUTO_INCREMENT PRIMARY KEY,
    asset_allocation_id INT NOT NULL,
    transfer_type ENUM(
        'employee_to_employee',
        'employee_to_department',
        'department_to_employee',
        'department_to_department'
    ) NOT NULL,
    current_owner_employee_id INT NULL,
    current_owner_department_id INT NULL,
    requested_owner_employee_id INT NULL,
    requested_owner_department_id INT NULL,
    requested_by_employee_id INT NOT NULL,
    approver_employee_id INT NULL,
    request_reason TEXT NOT NULL,
    approval_rejection_reason TEXT NULL,
    request_status ENUM(
        'requested',
        'approved',
        'rejected',
        'cancelled',
        'completed'
    ) NOT NULL DEFAULT 'requested',
    requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    decision_at DATETIME NULL,
    completed_at DATETIME NULL,
    resulting_asset_allocation_id INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_transfer_requests_asset_allocation_id (
        asset_allocation_id
    ),
    INDEX idx_transfer_requests_current_owner_employee_id (
        current_owner_employee_id
    ),
    INDEX idx_transfer_requests_current_owner_department_id (
        current_owner_department_id
    ),
    INDEX idx_transfer_requests_requested_owner_employee_id (
        requested_owner_employee_id
    ),
    INDEX idx_transfer_requests_requested_owner_department_id (
        requested_owner_department_id
    ),
    INDEX idx_transfer_requests_requested_by_employee_id (
        requested_by_employee_id
    ),
    INDEX idx_transfer_requests_approver_employee_id (
        approver_employee_id
    ),
    INDEX idx_transfer_requests_resulting_asset_allocation_id (
        resulting_asset_allocation_id
    ),
    INDEX idx_transfer_requests_status (request_status),
    INDEX idx_transfer_requests_requested_at (requested_at),
    INDEX idx_transfer_requests_decision_at (decision_at),
    INDEX idx_transfer_requests_status_requested_at (
        request_status,
        requested_at
    ),

    CONSTRAINT fk_transfer_requests_asset_allocation
        FOREIGN KEY (asset_allocation_id)
        REFERENCES asset_allocations (asset_allocation_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_transfer_requests_current_owner_employee
        FOREIGN KEY (current_owner_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_transfer_requests_current_owner_department
        FOREIGN KEY (current_owner_department_id)
        REFERENCES departments (department_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_transfer_requests_requested_owner_employee
        FOREIGN KEY (requested_owner_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_transfer_requests_requested_owner_department
        FOREIGN KEY (requested_owner_department_id)
        REFERENCES departments (department_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_transfer_requests_requested_by_employee
        FOREIGN KEY (requested_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_transfer_requests_approver_employee
        FOREIGN KEY (approver_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,

    CONSTRAINT fk_transfer_requests_resulting_asset_allocation
        FOREIGN KEY (resulting_asset_allocation_id)
        REFERENCES asset_allocations (asset_allocation_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;