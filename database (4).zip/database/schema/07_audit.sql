-- ============================================================
-- AssetFlow Audit Module
-- File: 07_audit.sql
-- MySQL 8.0.45 / InnoDB
-- ============================================================

-- ============================================================
-- Table: audit_cycles
-- Stores planned and completed asset-audit cycles, including
-- audit type, date range, status, and cycle creator details.
-- ============================================================

CREATE TABLE audit_cycles (
    audit_cycle_id INT AUTO_INCREMENT PRIMARY KEY,
    audit_cycle_name VARCHAR(150) NOT NULL,
    description TEXT NULL,
    audit_type ENUM(
        'scheduled',
        'surprise',
        'annual',
        'departmental',
        'other'
    ) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    audit_status ENUM(
        'planned',
        'in_progress',
        'completed',
        'cancelled'
    ) NOT NULL DEFAULT 'planned',
    created_by_employee_id INT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_audit_cycles_created_by_employee_id (
        created_by_employee_id
    ),
    INDEX idx_audit_cycles_audit_type (audit_type),
    INDEX idx_audit_cycles_audit_status (audit_status),
    INDEX idx_audit_cycles_start_date (start_date),
    INDEX idx_audit_cycles_end_date (end_date),
    INDEX idx_audit_cycles_status_start_date (
        audit_status,
        start_date
    ),

    CONSTRAINT fk_audit_cycles_created_by_employee
        FOREIGN KEY (created_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Table: audit_cycle_auditors
-- Bridge table that assigns one or more employees as auditors
-- for an audit cycle.
-- ============================================================

CREATE TABLE audit_cycle_auditors (
    audit_cycle_auditor_id INT AUTO_INCREMENT PRIMARY KEY,
    audit_cycle_id INT NOT NULL,
    employee_id INT NOT NULL,
    assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT uq_audit_cycle_auditors_cycle_employee
        UNIQUE (audit_cycle_id, employee_id),

    INDEX idx_audit_cycle_auditors_employee_id (employee_id),
    INDEX idx_audit_cycle_auditors_assigned_at (assigned_at),

    CONSTRAINT fk_audit_cycle_auditors_audit_cycle
        FOREIGN KEY (audit_cycle_id)
        REFERENCES audit_cycles (audit_cycle_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    CONSTRAINT fk_audit_cycle_auditors_employee
        FOREIGN KEY (employee_id)
        REFERENCES employees (employee_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Table: audit_items
-- Stores the audit result for each asset included in an audit
-- cycle. One asset can be recorded only once per audit cycle.
-- ============================================================

CREATE TABLE audit_items (
    audit_item_id INT AUTO_INCREMENT PRIMARY KEY,
    audit_cycle_id INT NOT NULL,
    asset_id INT NOT NULL,
    audited_by_employee_id INT NULL,
    audit_result ENUM(
        'matched',
        'missing',
        'damaged',
        'misplaced',
        'extra_found'
    ) NULL,
    remarks TEXT NULL,
    audited_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT uq_audit_items_cycle_asset UNIQUE (
        audit_cycle_id,
        asset_id
    ),

    INDEX idx_audit_items_asset_id (asset_id),
    INDEX idx_audit_items_audited_by_employee_id (
        audited_by_employee_id
    ),
    INDEX idx_audit_items_audit_result (audit_result),
    INDEX idx_audit_items_audited_at (audited_at),
    INDEX idx_audit_items_result_audited_at (
        audit_result,
        audited_at
    ),

    CONSTRAINT fk_audit_items_audit_cycle
        FOREIGN KEY (audit_cycle_id)
        REFERENCES audit_cycles (audit_cycle_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_audit_items_asset
        FOREIGN KEY (asset_id)
        REFERENCES assets (asset_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_audit_items_audited_by_employee
        FOREIGN KEY (audited_by_employee_id)
        REFERENCES employees (employee_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;